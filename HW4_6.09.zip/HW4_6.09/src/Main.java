import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scn = new Scanner(System.in);
        System.out.println("Введите ваше число");
        int num1 = scn.nextInt();
        int num2 = num1>>1;
        System.out.println(num2);
        }
}