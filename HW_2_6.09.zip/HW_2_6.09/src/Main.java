import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        //ДЗ2
        Scanner scn = new Scanner(System.in);
        System.out.println("Введите цену");
        double price = scn.nextDouble();
        System.out.println("Введите полученную сумму");
        double money = scn.nextDouble();
        double change = money-price;
        double dollar = (int) change;
        double cent = change*100%100;
        System.out.printf("Ваша сдача %.0f долларов и %.0f центов", dollar, cent);
    }
}