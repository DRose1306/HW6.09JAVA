import java.util.Random;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        // ДЗ1
        Random rnd = new Random();
        int metter = rnd.nextInt(1000,10000);
        System.out.println("Конвертируемое количество метров " + metter);
        double km = metter/1000f;
        double mi = metter/1609.344f;
        double ft = metter/0.3048f;
        double ar = metter*1.41f;
        System.out.printf("Киллометры: %.2f ", km );
        System.out.printf("Милли: %.2f", mi );
        System.out.printf("Футты: %.2f", ft );
        System.out.printf("Аршины %.2f: ", ar);
        // посмотеть и отделить строчки
    }
}