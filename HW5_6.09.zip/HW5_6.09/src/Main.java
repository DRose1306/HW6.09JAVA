public class Main {
    public static void main(String[] args) {
        int a = 1;
        int b = 2;
        System.out.println("a = " + a + "b = " + b);
        a = a ^ b;
        b = b ^ a;
        System.out.println("a = " + a + "b = " + b);
        //c=a^b a=c^b
    }
}