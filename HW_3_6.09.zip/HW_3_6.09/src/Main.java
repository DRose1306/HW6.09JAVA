public class Main {
    public static void main(String[] args) {
boolean isYearFinished = true;
boolean isGoodWeather = true;
boolean hasBoughtRaincoast = true;
boolean isJimFree = false;
boolean hasKateComeBack = true;
boolean isPohodHappend = isYearFinished && (isGoodWeather || hasBoughtRaincoast) && (isJimFree ^ hasKateComeBack);
        System.out.println(isPohodHappend);

    }
}
//boolean isExpeditionHappend = (isBrigadirPresented || isZamPresented) &&
// isGeodezistPresented && isGeologPresented

//                &&(isDriver1Presented ^ isDriver2Presented);